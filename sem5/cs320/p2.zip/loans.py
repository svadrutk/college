import json
import zipfile
import csv
from io import TextIOWrapper

race_lookup = {
    "1": "American Indian or Alaska Native",
    "2": "Asian",
    "3": "Black or African American",
    "4": "Native Hawaiian or Other Pacific Islander",
    "5": "White",
    "21": "Asian Indian",
    "22": "Chinese",
    "23": "Filipino",
    "24": "Japanese",
    "25": "Korean",
    "26": "Vietnamese",
    "27": "Other Asian",
    "41": "Native Hawaiian",
    "42": "Guamanian or Chamorro",
    "43": "Samoan",
    "44": "Other Pacific Islander"
}

values = {'activity_year': '2021', 'lei': '549300Q76VHK6FGPX546', 'derived_msa-md': '24580', 'state_code': 'WI','county_code': '55009', 'census_tract': '55009020702', 'conforming_loan_limit': 'C', 'derived_loan_product_type': 'Conventional:First Lien', 'derived_dwelling_category': 'Single Family (1-4 Units):Site-Built', 'derived_ethnicity': 'Not Hispanic or Latino', 'derived_race': 'White', 'derived_sex': 'Joint', 'action_taken': '1', 'purchaser_type': '1', 'preapproval': '2', 'loan_type': '1', 'loan_purpose': '31', 'lien_status': '1', 'reverse_mortgage': '2', 'open-end_line_of_credit': '2', 'business_or_commercial_purpose': '2', 'loan_amount': '325000.0', 'loan_to_value_ratio': '73.409', 'interest_rate': '2.5', 'rate_spread': '0.304', 'hoepa_status': '2', 'total_loan_costs': '3932.75', 'total_points_and_fees': 'NA', 'origination_charges': '3117.5', 'discount_points': '', 'lender_credits': '', 'loan_term': '240', 'prepayment_penalty_term': 'NA', 'intro_rate_period': 'NA', 'negative_amortization': '2', 'interest_only_payment': '2', 'balloon_payment': '2', 'other_nonamortizing_features': '2', 'property_value': '445000', 'construction_method': '1', 'occupancy_type': '1', 'manufactured_home_secured_property_type': '3', 'manufactured_home_land_property_interest': '5', 'total_units': '1', 'multifamily_affordable_units': 'NA', 'income': '264', 'debt_to_income_ratio': '20%-<30%', 'applicant_credit_score_type': '2', 'co-applicant_credit_score_type': '9', 'applicant_ethnicity-1': '2', 'applicant_ethnicity-2': '', 'applicant_ethnicity-3': '', 'applicant_ethnicity-4': '', 'applicant_ethnicity-5': '', 'co-applicant_ethnicity-1': '2', 'co-applicant_ethnicity-2': '', 'co-applicant_ethnicity-3': '', 'co-applicant_ethnicity-4': '', 'co-applicant_ethnicity-5': '', 'applicant_ethnicity_observed': '2', 'co-applicant_ethnicity_observed': '2', 'applicant_race-1': '5', 'applicant_race-2': '', 'applicant_race-3': '', 'applicant_race-4': '', 'applicant_race-5': '', 'co-applicant_race-1': '5', 'co-applicant_race-2': '', 'co-applicant_race-3': '', 'co-applicant_race-4': '', 'co-applicant_race-5': '', 'applicant_race_observed': '2', 'co-applicant_race_observed': '2', 'applicant_sex': '1', 'co-applicant_sex': '2', 'applicant_sex_observed': '2', 'co-applicant_sex_observed': '2', 'applicant_age': '35-44', 'co-applicant_age': '35-44', 'applicant_age_above_62': 'No', 'co-applicant_age_above_62': 'No', 'submission_of_application': '1', 'initially_payable_to_institution': '1', 'aus-1': '1', 'aus-2': '', 'aus-3': '', 'aus-4': '', 'aus-5': '', 'denial_reason-1': '10', 'denial_reason-2': '', 'denial_reason-3': '', 'denial_reason-4': '', 'tract_population': '6839', 'tract_minority_population_percent': '8.85999999999999943', 'ffiec_msa_md_median_family_income': '80100', 'tract_to_msa_income_percentage': '150', 'tract_owner_occupied_units': '1701', 'tract_one_to_four_family_homes': '2056', 'tract_median_age_of_housing_units': '15'}

class Applicant:
    def __init__(self, age, race):
        self.age = age
        self.race = set()
        for r in race:
            if r != '' and r in race_lookup:
                self.race.add(race_lookup[r])
    def __repr__(self):
        sortedRace = sorted(self.race)
        return f'Applicant(\'{self.age}\', {sortedRace})'
    def lower_age(self):
        if '<' in self.age or '>' in self.age: 
            age = self.age.replace('<', '')
            age = age.replace('>', '')
            return int(age)
        else:
            return int(self.age[:self.age.find('-')])
            
    def __lt__(self, other):
        return self.lower_age() < other.lower_age()

################################################################################

class Loan:
    def __init__(self, values):
        if values["loan_amount"] == 'NA' or values["loan_amount"] == 'Exempt':
            self.loan_amount = -1
        else:
            self.loan_amount = float(values["loan_amount"])
        if values["property_value"] == 'NA' or values["property_value"] == 'Exempt':
            self.property_value = -1
        else:
            self.property_value = float(values["property_value"])
        if values["interest_rate"] == 'NA' or values["interest_rate"] == 'Exempt':
            self.interest_rate = -1
        else:
            self.interest_rate = float(values["interest_rate"]) 
        ###################

        self.applicants = [] 
        self.num_applicants = 1
        if values["co-applicant_age"] != "9999": 
            self.num_applicants = 2

        if self.num_applicants == 1: 
            newApplicant = Applicant(values["applicant_age"], [values["applicant_race-1"], values["applicant_race-2"], values["applicant_race-3"], values["applicant_race-4"], values["applicant_race-5"]])
            self.applicants.append(newApplicant)
        elif self.num_applicants == 2: 
            newApplicant = Applicant(values["applicant_age"], [values["applicant_race-1"], values["applicant_race-2"], values["applicant_race-3"], values["applicant_race-4"], values["applicant_race-5"]])
            coApplicant = Applicant(values["co-applicant_age"], [values["co-applicant_race-1"], values["co-applicant_race-2"], values["co-applicant_race-3"], values["co-applicant_race-4"], values["co-applicant_race-5"]])
            self.applicants.append(newApplicant) 
            self.applicants.append(coApplicant)
    def __str__(self): 
        return f'<Loan: {self.interest_rate}% on ${self.property_value} with {self.num_applicants} applicant(s)>'
    def __repr__(self):
        return f'<Loan: {self.interest_rate}% on ${self.property_value} with {self.num_applicants} applicant(s)>'
    def yearly_amounts(self, yearly_payment):
        # TODO: assert interest and amount are positive
        assert self.interest_rate > 0 and self.loan_amount > 0
        amt = self.loan_amount
    
        while amt > 0:
            yield amt
            # TODO: add interest rate multiplied by amt to amt
            # TODO: subtract yearly payment from amt
            interest = float(self.interest_rate) * 0.01
            amt = amt + (amt * interest) 
            amt -= yearly_payment


################################################################################

with open('banks.json', 'r') as json_file:
    banksJson = json.load(json_file)


class Bank: 
    def __init__(self, name):
        self.loanList = [] 
        self.lei = 0
        for dictionary in banksJson: 
            if dictionary["name"] == name: 
                self.lei = dictionary["lei"]
                break
        ###################
        with zipfile.ZipFile('wi.zip', 'r') as zip_ref: 
            self.file_list = zip_ref.namelist()
            for file_name in self.file_list:
                if file_name.endswith('.csv'):
                    # Extract the CSV file from the ZIP archive
                    with zip_ref.open(file_name) as csv_file:
                        # Read the CSV file using csv.reader
                        csv_reader = csv.DictReader(TextIOWrapper(csv_file, 'utf-8'))
                        for row in csv_reader: 
                            if row["lei"] == self.lei: 
                                self.loanList.append(Loan(row))
    def __getitem__(self, index):
        return self.loanList[index]
    def __len__(self): 
        return len(self.loanList)
                                
                
                
        
                
            
        
        
    
            


            
    
    

