public class AddBlueFishButton extends Button implements TankListener {
    public AddBlueFishButton(float x, float y) {
        super("Add Blue", x, y);
    }
    public void mousePressed() {
        System.out.println("Mouse has been pressed.");
        if(this.isMouseOver()) {
            tank.objects.add(new BlueFish());
        }
    }
}
