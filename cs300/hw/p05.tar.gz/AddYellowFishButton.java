public class AddYellowFishButton extends Button implements TankListener {
    public AddYellowFishButton(float x, float y) {
        super("Add Yellow", x, y);
    }
    public void mousePressed() {
        if(this.isMouseOver()) {
            tank.objects.add(new Fish(2, "yellow.png"));
        }
    }
}
