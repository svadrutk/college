public class AddOrangeFishButton extends Button {
    public AddOrangeFishButton(float x, float y) {
        super("Add Orange", x, y);
    }
    public void mousePressed() {
        if(this.isMouseOver()) {
            tank.objects.add(new Fish());
        }
    }
}
