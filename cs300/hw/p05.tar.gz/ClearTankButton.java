public class ClearTankButton extends Button {
    public ClearTankButton(float x, float y) {
        super("Clear", x, y);
    }

    public void mousePressed() {
        if(this.isMouseOver()) {
            tank.clear();
        }
    }
}
